
export default function Error() {
  return <div>Error</div>;
}
