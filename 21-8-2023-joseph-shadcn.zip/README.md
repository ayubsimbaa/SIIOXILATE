## Features:

1. Implemented nested layout
2. Added Skeleton for loading
3. Added custom Error page
4. Added popover from shadcn
5. Added button from shadcn
6.
